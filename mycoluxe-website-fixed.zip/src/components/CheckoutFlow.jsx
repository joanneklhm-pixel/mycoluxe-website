export default function CheckoutFlow() {
  return (
    <div className="bg-black text-white min-h-screen flex items-center justify-center">
      <h1 className="text-gold text-4xl font-serif">CheckoutFlow Page</h1>
    </div>
  );
}
