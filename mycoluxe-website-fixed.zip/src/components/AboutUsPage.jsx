export default function AboutUsPage() {
  return (
    <div className="bg-black text-white min-h-screen flex items-center justify-center">
      <h1 className="text-gold text-4xl font-serif">AboutUsPage Page</h1>
    </div>
  );
}
