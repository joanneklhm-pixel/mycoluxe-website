# MycoLuxe Botanicals Website (Fixed)

This is a React + Tailwind + Vite project scaffold for the MycoLuxe Botanicals luxury supplement brand.

## Getting Started
1. Install dependencies: `npm install`
2. Run locally: `npm run dev`
3. Build for production: `npm run build`

Includes pages: Home, Shop, Product, Education, About, Contact, Checkout
